<?php
/**
 * Menampilkan riwayat pesanan pelanggan beserta status transaksi yang telah dilakukan.
 */
session_start(); 
include __DIR__ . "/../config/koneksi.php";

// Menambahkan kolom khusus proses pengembalian jika belum tersedia.
$kolom_pengembalian = [
    'bukti_unboxing' => "ALTER TABLE pesanan ADD bukti_unboxing VARCHAR(255) NULL",
];
foreach ($kolom_pengembalian as $nama_kolom => $sql_tambah) {
    $cek_kolom = mysqli_query($conn, "SHOW COLUMNS FROM pesanan LIKE '$nama_kolom'");
    if ($cek_kolom && mysqli_num_rows($cek_kolom) === 0) {
        mysqli_query($conn, $sql_tambah);
    }
}
 

$loggedIn = isset($_SESSION['id_user']); 
$query = false;

if ($loggedIn) {
    $id_user = $_SESSION['id_user'];
    $query = mysqli_query($conn, "SELECT * FROM pesanan WHERE id_user='$id_user' ORDER BY id_pesanan DESC");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Pesanan Saya - NEO BSTORE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex min-vh-100">
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
            </div>
            <nav class="sidebar-nav">
                <a href="../index.php">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Beranda</span>
                </a>
                <a href="kategori.php">
                    <i class="bi bi-bar-chart-steps">
                    </i><span>Kategori</span>
                </a>
                <a href="cart.php">
                    <i class="bi bi-cart3"></i>
                    <span>Keranjang</span>
                </a>
                <a href="pesanan.php" class="active">
                    <i class="bi bi-box-seam">
                    </i><span>Pesanan Saya</span>
                </a>
                <a href="about.php">
                    <i class="bi bi-info-circle">
                    </i><span>Tentang Kami</span>
                </a>
                <a href="contact.php">
                    <i class="bi bi-chat-dots">
                    </i><span>Hubungi Admin</span>
                </a>
                <?php if ($loggedIn): ?>
                    <a href="../logout.php" class="text-danger mt-auto">
                        <i class="bi bi-box-arrow-right"></i>
                        <span>Logout</span></a>
                <?php else: ?>
                    <a href="../login.php" class="text-primary mt-auto"><i class="bi bi-box-arrow-in-right"></i><span>Login / Daftar</span></a>
                <?php endif; ?>
            </nav>
        </aside>

        <main class="content-wrapper">
            <div class="mb-4">
                <h3 class="fw-bold">Pesanan Saya</h3>
                <p class="text-muted small">Lihat riwayat dan status pesanan Anda.</p>
            </div>

            <?php if (!$loggedIn): ?>
                <div class="card border-0 shadow-sm rounded-4 p-5 text-center bg-white">
                    <div class="mx-auto mb-3 d-flex align-items-center justify-content-center rounded-circle bg-primary-subtle text-primary" style="width:72px;height:72px">
                        <i class="bi bi-box-seam fs-2"></i>
                    </div>
                    <h5 class="fw-bold">Pesanan Saya</h5>
                    <p class="text-muted mb-4">Login untuk melihat riwayat pesanan dan status pembelian.</p>
                    <div class="d-flex justify-content-center gap-2">
                        <a href="../login.php?redirect=pesanan" class="btn btn-primary rounded-pill px-4">Login</a>
                        <a href="../register.php" class="btn btn-outline-primary rounded-pill px-4">Daftar</a>
                    </div>
                </div>
            <?php else: ?>
                <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-primary">
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal</th>
                                    <th>Total</th>
                                    <th>Metode</th>
                                    <th>Status</th>
                                    <th class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $no = 1;
                                $ada = false;
                                while ($p = mysqli_fetch_assoc($query)) {
                                    $ada = true;
                                    $st = trim((string)$p['status']) !== '' ? $p['status'] : 'Menunggu Pembayaran';
                                    $badge = 'bg-secondary';
                                    
                                    if ($st === 'Menunggu Pembayaran' || $st === 'Menunggu') {
                                        $badge = 'bg-warning text-dark';
                                    } elseif ($st === 'Menunggu Verifikasi') {
                                        $badge = 'bg-info text-dark';
                                    } elseif ($st === 'Diproses' || $st === 'Dikirim') {
                                        $badge = 'bg-primary';
                                    } elseif (in_array($st, ['Diterima', 'Pengajuan Pengembalian', 'Pengembalian Disetujui', 'Menunggu Barang Dikembalikan'])) {
                                        $badge = 'bg-info text-dark';
                                    } elseif (in_array($st, ['Selesai', 'Dana Dikembalikan'])) {
                                        $badge = 'bg-success';
                                    } 
                                ?>
                                    <tr>
                                        <td><?=$no++;?></td>
                                        <td><?=htmlspecialchars($p['tanggal']);?></td>
                                        <td>Rp <?=number_format($p['total'], 0, ',', '.');?></td>
                                        <td><?=htmlspecialchars($p['metode_pembayaran']);?></td>
                                        <td>
                                            <div class="d-flex flex-column align-items-start gap-2">
                                                <span class="badge <?=$badge;?>"><?=htmlspecialchars($st);?></span>
                                                <?php if ($st === 'Dikirim'): ?>
                                                    <a href="terima_pesanan.php?id=<?=$p['id_pesanan'];?>" class="btn btn-success btn-sm rounded-pill px-2 py-1" style="font-size: 11px;" onclick="return confirm('Apakah Anda yakin pesanan sudah diterima?')">
                                                        <i class="bi bi-check-circle"></i> Konfirmasi Terima
                                                    </a>
                                                <?php elseif ($st === 'Diterima'): ?>
                                                    <a href="ajukan_pengembalian.php?id=<?=$p['id_pesanan'];?>" class="btn btn-outline-danger btn-sm rounded-pill px-2 py-1" style="font-size: 11px;">
                                                        <i class="bi bi-arrow-counterclockwise"></i> Ajukan Pengembalian
                                                    </a>
                                                    <a href="terima_pesanan.php?id=<?=$p['id_pesanan'];?>&aksi=selesai" class="btn btn-success btn-sm rounded-pill px-2 py-1" style="font-size: 11px;" onclick="return confirm('Selesaikan pesanan ini?')">
                                                        <i class="bi bi-check-circle"></i> Selesai
                                                    </a>
                                                <?php elseif ($st === 'Pengembalian Disetujui'): ?>
                                                    <a href="terima_pesanan.php?id=<?=$p['id_pesanan'];?>&aksi=kirim_kembali" class="btn btn-warning btn-sm rounded-pill px-2 py-1" style="font-size: 11px;" onclick="return confirm('Konfirmasi bahwa barang sudah Anda kirim kembali?')">
                                                        <i class="bi bi-truck"></i> Barang Dikirim Kembali
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="text-center">
                                            <a href="detail_pesanan.php?id=<?=$p['id_pesanan'];?>" class="btn btn-outline-primary btn-sm rounded-pill px-3 fw-medium">
                                                <i class="bi bi-eye"></i> Detail
                                            </a>
                                        </td>
                                    </tr>
                                <?php } ?>

                                <?php if (!$ada): ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-5 text-muted">Belum ada pesanan.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>