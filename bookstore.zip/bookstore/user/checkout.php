<?php
/**
 * Memproses checkout, memvalidasi item dan data pembayaran, menyimpan transaksi, serta mengelola bukti pembayaran.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

// Cek autentikasi user
if (!isset($_SESSION['id_user'])) {
    header('Location: ../login.php?redirect=checkout');
    exit;
}

$id_user = $_SESSION['id_user'];
$total = 0;
$items = [];
$selected_ids = [];

// Cek apakah diakses dari Beli Langsung (Detail/Beranda) atau dari Checkbox Keranjang
if (isset($_GET['id_buku']) && isset($_GET['qty'])) {
    $id_buku = mysqli_real_escape_string($conn, $_GET['id_buku']);
    $qty = (int)$_GET['qty'];

    $q = mysqli_query($conn, "SELECT * FROM buku WHERE id_buku = '$id_buku'");
    if ($buku = mysqli_fetch_assoc($q)) {
        $subtotal = $buku['harga'] * $qty;
        $total += $subtotal;
        $items[] = [
            'id_buku' => $buku['id_buku'],
            'judul' => $buku['judul'],
            'harga' => $buku['harga'],
            'jumlah' => $qty,
            'subtotal' => $subtotal
        ];
    }
} else {
    // Jika dari keranjang, ambil berdasarkan data checkbox yang dikirim via POST (selected_items)
    if (isset($_POST['selected_items']) && is_array($_POST['selected_items'])) {
        $selected_ids = $_POST['selected_items'];
    } elseif (isset($_SESSION['selected_checkout'])) {
        $selected_ids = $_SESSION['selected_checkout'];
    }

    if (!empty($selected_ids)) {
        $_SESSION['selected_checkout'] = $selected_ids;
        $ids_string = implode(',', array_map('intval', $selected_ids));

        $q = mysqli_query($conn, "SELECT cart.*, buku.judul, buku.harga, buku.id_buku 
                                  FROM cart 
                                  JOIN buku ON cart.id_buku = buku.id_buku 
                                  WHERE cart.id_user = '$id_user' AND cart.id_cart IN ($ids_string)");

        while ($c = mysqli_fetch_assoc($q)) {
            $c['subtotal'] = $c['harga'] * $c['jumlah'];
            $total += $c['subtotal'];
            $items[] = $c;
        }
    }
}

if (empty($items)) {
    header('Location: cart.php');
    exit;
}

$error = '';
if (isset($_POST['proses_checkout'])) {
    $metode = mysqli_real_escape_string($conn, $_POST['metode_pembayaran']);
    $nama_bukti = NULL;

    // Logika Validasi & Upload Bukti Pembayaran (Non-COD)
    if ($metode !== 'COD (Bayar di Tempat)') {
        if (!isset($_FILES['bukti_bayar']) || $_FILES['bukti_bayar']['error'] !== UPLOAD_ERR_OK) {
            $error = 'Silakan unggah bukti pembayaran terlebih dahulu.';
        } else {
            $ext = strtolower(pathinfo($_FILES['bukti_bayar']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg', 'jpeg', 'png'], true)) {
                $error = 'Format bukti pembayaran harus JPG, JPEG, atau PNG.';
            } elseif ($_FILES['bukti_bayar']['size'] > 2 * 1024 * 1024) {
                $error = 'Ukuran file bukti pembayaran maksimal 2 MB.';
            } else {
                $dir = __DIR__ . '/../assets/img/bukti_bayar/';
                if (!is_dir($dir)) {
                    mkdir($dir, 0777, true);
                }
                $nama_bukti = 'bukti_' . $id_user . '_' . time() . '_' . bin2hex(random_bytes(3)) . '.' . $ext;
                if (!move_uploaded_file($_FILES['bukti_bayar']['tmp_name'], $dir . $nama_bukti)) {
                    $error = 'Gagal mengunggah bukti pembayaran.';
                }
            }
        }
    }

    if (empty($error)) {
        $status = ($metode === 'COD (Bayar di Tempat)') ? 'Menunggu' : 'Menunggu Verifikasi';
        $bukti_val = $nama_bukti ? "'$nama_bukti'" : "NULL";

        // Simpan ke tabel pesanan
        $ok = mysqli_query($conn, "INSERT INTO pesanan (id_user, tanggal, total, metode_pembayaran, bukti_bayar, status) 
                                   VALUES ('$id_user', NOW(), '$total', '$metode', $bukti_val, '$status')");

        if ($ok) {
            $id_pesanan_baru = mysqli_insert_id($conn);
            foreach ($items as $it) {
                mysqli_query($conn, "INSERT INTO detail_pesanan (id_pesanan, id_buku, jumlah, harga) 
                                     VALUES ('$id_pesanan_baru', '{$it['id_buku']}', '{$it['jumlah']}', '{$it['harga']}')");
            }
            
            if (!isset($_GET['id_buku']) && !empty($selected_ids)) {
                $ids_string = implode(',', array_map('intval', $selected_ids));
                mysqli_query($conn, "DELETE FROM cart WHERE id_user = '$id_user' AND id_cart IN ($ids_string)");
                unset($_SESSION['selected_checkout']);
            }
            
            header("Location: detail_pesanan.php?id=$id_pesanan_baru&new=1");
            exit;
        } else {
            $error = 'Pesanan gagal dibuat: ' . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - NEO BSTORE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex min-vh-100">
        <!-- Sidebar -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand d-flex align-items-center gap-2">
                <i class="bi bi-book-half fs-3 text-primary"></i>
                <h3 class="logo-text mb-0">NEO <span>BSTORE</span></h3>
            </div>
            <nav class="sidebar-nav">
                <a href="../index.php">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Beranda</span>
                </a>
                <a href="kategori.php">
                    <i class="bi bi-bar-chart-steps"></i>
                    <span>Kategori</span>
                </a>
                <a href="cart.php" class="active">
                    <i class="bi bi-cart3"></i>
                    <span>Keranjang</span>
                </a>
                <a href="pesanan.php">
                    <i class="bi bi-box-seam"></i>
                    <span>Pesanan Saya</span>
                </a>
                <a href="about.php">
                    <i class="bi bi-info-circle"></i>
                    <span>Tentang Kami</span>
                </a>
                <a href="contact.php">
                    <i class="bi bi-chat-dots"></i>
                    <span>Hubungi Admin</span>
                </a>
                <a href="../logout.php" class="text-danger mt-auto">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Logout</span>
                </a>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="content-wrapper">
            <div class="mb-4">
                <h3 class="fw-bold">Checkout</h3>
                <p class="text-muted small">Periksa pembelian lalu pilih metode pembayaran dan unggah bukti transfer (jika non-COD) untuk mencetak struk.</p>
            </div>

            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <div class="row g-4">
                <!-- Ringkasan Pembelian (Diubah jadi col-lg-7 agar proporsional) -->
                <div class="col-lg-7">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
                        <div class="card-header bg-white py-3">
                            <h6 class="fw-bold mb-0">
                                <i class="bi bi-receipt me-2 text-primary"></i>Ringkasan Pembelian Pilihan
                            </h6>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th class="ps-4">Buku</th>
                                        <th>Harga</th>
                                        <th>Jumlah</th>
                                        <th class="text-end pe-4">Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($items as $it): ?>
                                        <tr>
                                            <td class="ps-4 fw-bold text-dark"><?= htmlspecialchars($it['judul']); ?></td>
                                            <td>Rp <?= number_format($it['harga'], 0, ',', '.'); ?></td>
                                            <td><?= $it['jumlah']; ?></td>
                                            <td class="text-end pe-4 fw-bold text-success">Rp <?= number_format($it['subtotal'], 0, ',', '.'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Pilihan Pembayaran & Form Bukti (Diubah jadi col-lg-5 agar lebih luas dan tidak terpotong) -->
                <div class="col-lg-5">
                    <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                        <h6 class="fw-bold mb-3">Metode Pembayaran</h6>
                        <form method="POST" enctype="multipart/form-data">
                            <select name="metode_pembayaran" id="metode" class="form-select mb-3 rounded-3" required>
                                <option>Transfer Bank MANDIRI - 0123456789</option>
                                <option>Transfer Bank BNI - 0123346575</option>
                                <option>Transfer Bank BCA - 01230987866</option>
                                <option>Transfer Bank BRI - 01232998568</option>
                            </select>

                            <div id="info" class="alert alert-info small mb-3"></div>

                            <!-- Input Bukti Pembayaran (Ditampilkan jika Non-COD) -->
                            <div id="wrapper_bukti" class="mb-3" style="display: none;">
                                <label class="form-label fw-semibold small">Upload Bukti Pembayaran</label>
                                <input type="file" name="bukti_bayar" id="bukti_bayar" class="form-control rounded-3" accept=".jpg,.jpeg,.png">
                                <small class="text-muted d-block mt-1">Format: JPG, JPEG, PNG (Maks. 2 MB)</small>
                            </div>

                            <!-- Bagian Total Harga Dibuat Sejajar Ke Samping -->
                            <div class="d-flex justify-content-between align-items-center border-top pt-3 mb-3">
                                <span class="fw-semibold text-secondary">Total Pembayaran</span>
                                <strong class="text-success fs-5">Rp <?= number_format($total, 0, ',', '.'); ?></strong>
                            </div>

                            <button name="proses_checkout" class="btn btn-success w-100 rounded-pill py-2 fw-bold mb-2">
                                <i class="bi bi-printer me-1"></i>Buat Pesanan & Cetak Struk
                            </button>
                            <a href="cart.php" class="btn btn-outline-secondary w-100 rounded-pill py-2">Kembali ke Keranjang</a>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Script Logika Frontend -->
    <script>
        const m = document.getElementById('metode');
        const i = document.getElementById('info');
        const wrapperBukti = document.getElementById('wrapper_bukti');
        const inputBukti = document.getElementById('bukti_bayar');
        
        // Menyesuaikan informasi pembayaran yang ditampilkan berdasarkan metode pembayaran terpilih.
        
        function updateMetodeInfo() {
            if (m.value === 'COD (Bayar di Tempat)') {
                i.innerHTML = '<b>COD:</b> Pembayaran dilakukan saat buku diterima. Struk akan langsung dicetak.';
                wrapperBukti.style.display = 'none';
                inputBukti.removeAttribute('required');
            } else {
                i.innerHTML = '<b>' + m.value + ':</b> Silakan transfer sesuai total belanja lalu unggah bukti pembayaran di bawah ini.';
                wrapperBukti.style.display = 'block';
                inputBukti.setAttribute('required', 'required');
            }
        }

        m.addEventListener('change', updateMetodeInfo);
        updateMetodeInfo();
    </script>
</body>
</html>