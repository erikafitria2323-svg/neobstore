<?php
/**
 * Memproses konfirmasi penerimaan, penyelesaian pesanan, atau pengiriman balik barang oleh user.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

if (!isset($_SESSION['id_user'])) {
    header("Location: ../login.php");
    exit;
}

$id_pesanan = isset($_GET['id']) ? intval($_GET['id']) : 0;
$id_user = intval($_SESSION['id_user']);
$aksi = $_GET['aksi'] ?? 'diterima';

$stmt = mysqli_prepare($conn, "SELECT status FROM pesanan WHERE id_pesanan=? AND id_user=?");
mysqli_stmt_bind_param($stmt, 'ii', $id_pesanan, $id_user);
mysqli_stmt_execute($stmt);
$data = mysqli_stmt_get_result($stmt)->fetch_assoc();

if ($data) {
    if ($aksi === 'diterima' && $data['status'] === 'Dikirim') {
        $status = 'Diterima';
    } elseif ($aksi === 'selesai' && $data['status'] === 'Diterima') {
        $status = 'Selesai';
    } elseif ($aksi === 'kirim_kembali' && $data['status'] === 'Pengembalian Disetujui') {
        $status = 'Menunggu Barang Dikembalikan';
    } else {
        $status = null;
    }

    if ($status !== null) {
        $up = mysqli_prepare($conn, "UPDATE pesanan SET status=? WHERE id_pesanan=? AND id_user=?");
        mysqli_stmt_bind_param($up, 'sii', $status, $id_pesanan, $id_user);
        mysqli_stmt_execute($up);
    }
}

header("Location: pesanan.php");
exit;
?>
