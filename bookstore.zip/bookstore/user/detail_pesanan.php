<?php
/**
 * Menampilkan rincian transaksi milik pelanggan, termasuk item buku, total pembayaran, dan status pesanan.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

// Cek autentikasi user
if (!isset($_SESSION['id_user'])) {
    header('Location: ../login.php');
    exit;
}

$uid = $_SESSION['id_user'];
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Ambil data pesanan dan JOIN dengan tabel user untuk mengambil data nama, alamat, dan no_hp
$s = mysqli_prepare($conn, "
    SELECT pesanan.*, user.nama AS nama_user, user.email, user.alamat, user.no_hp 
    FROM pesanan 
    JOIN user ON pesanan.id_user = user.id_user 
    WHERE pesanan.id_pesanan = ? AND pesanan.id_user = ?
");
mysqli_stmt_bind_param($s, 'ii', $id, $uid);
mysqli_stmt_execute($s);
$o = mysqli_stmt_get_result($s)->fetch_assoc();

if (!$o) {
    echo "<script>alert('Struk tidak ditemukan.'); window.location='pesanan.php';</script>";
    exit;
}

// Generate Kode Transaksi Unik (Contoh: NBS101126001)
$tgl_format = date('dmy', strtotime($o['tanggal']));
$kode_transaksi = 'NBS' . $tgl_format . str_pad($o['id_pesanan'], 3, '0', STR_PAD_LEFT);

// Ambil rincian item buku
$s_detail = mysqli_prepare($conn, "SELECT detail_pesanan.*, buku.judul 
                                   FROM detail_pesanan 
                                   JOIN buku ON detail_pesanan.id_buku = buku.id_buku 
                                   WHERE detail_pesanan.id_pesanan = ?");
mysqli_stmt_bind_param($s_detail, 'i', $id);
mysqli_stmt_execute($s_detail);
$details = mysqli_stmt_get_result($s_detail);

// Fungsi format rupiah
if (!function_exists('rupiah')) {
    function rupiah($angka)
    {
        return 'Rp ' . number_format($angka, 0, ',', '.');
    }
}

// Fungsi escape HTML aman
if (!function_exists('e')) {
    function e($val)
    {
        return htmlspecialchars($val ?? '', ENT_QUOTES, 'UTF-8');
    }
}
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Pesanan #<?= $kode_transaksi; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        @media print {
            .actions,
            .bukti-section-web,
            .alert,
            .sidebar-wrapper {
                display: none !important;
            }

            body {
                background: white !important;
            }

            .receipt {
                box-shadow: none !important;
                margin: 0 !important;
                padding: 0 !important;
                width: 100% !important;
            }
        }
    </style>
</head>

<body class="bg-light py-4">

    <div class="container" style="max-width: 700px;">

        <?php if (isset($_GET['new'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i> Pesanan berhasil dibuat dan struk telah diterbitkan.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <!-- Area Struk Pembelian -->
        <div class="receipt card border-0 shadow-sm p-4 bg-white rounded-4 mb-4" id="receipt">

            <div class="receipt-head text-center mb-3">
                <h1 class="fw-bold mb-0">NEO</h1>
                <b>BOOKSTORE</b>
                <p class="text-muted small mb-0">STRUK PEMBELIAN</p>
            </div>

            <p class="mb-3">
                <b>Kode Transaksi:</b> <span class="text-primary fw-bold"><?= $kode_transaksi; ?></span><br>
                <b>Tanggal:</b> <?= date('d F Y, H:i', strtotime($o['tanggal'])) ?>
            </p>

            <h6 class="fw-bold text-dark border-bottom pb-1"><i class="bi bi-person-lines-fill me-1"></i> Data Penerima & Pengiriman</h6>
            <div class="mb-3 small">
                <p class="mb-1"><b>Nama:</b> <?= e($o['nama_user']) ?></p>
                <p class="mb-1"><b>No. HP / WhatsApp:</b> <?= !empty($o['no_hp']) ? e($o['no_hp']) : '<span class="text-muted fst-italic">Belum diisi</span>'; ?></p>
                <p class="mb-0"><b>Alamat Tujuan:</b> <?= !empty($o['alamat']) ? nl2br(e($o['alamat'])) : '<span class="text-danger fst-italic">Belum diisi</span>'; ?></p>
            </div>

            <table class="table table-sm align-middle">
                <thead>
                    <tr>
                        <th>Buku</th>
                        <th>Qty</th>
                        <th>Harga</th>
                        <th class="text-end">Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($d = mysqli_fetch_assoc($details)): 
                        $subtotal_item = $d['harga'] * $d['jumlah'];
                    ?>
                        <tr>
                            <td><?= e($d['judul']) ?></td>
                            <td><?= $d['jumlah'] ?></td>
                            <td><?= rupiah($d['harga']) ?></td>
                            <td class="text-end"><?= rupiah($subtotal_item) ?></td>
                        </tr>
                    <?php endwhile ?>
                </tbody>
            </table>

            <p class="text-end mb-3">
                <span class="fs-5 text-success"><b>Total: <?= rupiah($o['total']) ?></b></span>
            </p>

            <p class="border-top pt-2 mb-3">
                Metode Pembayaran: <b><?= e($o['metode_pembayaran']) ?></b><br>
                Status Pesanan: <b><?= e($o['status']) ?></b>
            </p>

            <p class="text-center text-muted small mt-4 mb-0">
                <b>Terima kasih telah berbelanja di NEO BSTORE!</b>
            </p>

            <!-- Tombol Aksi -->
            <div class="actions d-flex flex-wrap gap-2 justify-content-center mt-4 pt-3 border-top">
                <button class="btn btn-primary rounded-pill px-4" onclick="window.print()">
                    <i class="bi bi-printer me-1"></i> Cetak Struk
                </button>

                <button class="btn btn-outline-primary rounded-pill px-4" onclick="window.print()">
                    <i class="bi bi-file-earmark-pdf me-1"></i> Simpan sebagai PDF
                </button>

                <a class="btn btn-outline-secondary rounded-pill px-4" href="pesanan.php">
                    Lihat Pesanan Saya
                </a>

                <a class="btn btn-outline-dark rounded-pill px-4" href="../index.php">
                    Kembali ke Home
                </a>
            </div>
        </div>

        <!-- Bagian Bukti Pembayaran -->
        <?php if (!empty($o['bukti_bayar'])): ?>
            <div class="bukti-section-web card border-0 shadow-sm p-4 bg-white rounded-4">
                <h5 class="fw-bold mb-3"><i class="bi bi-image me-2 text-primary"></i>Bukti Pembayaran Anda</h5>
                <p class="text-muted small">Berikut adalah bukti pembayaran yang telah Anda unggah untuk pesanan ini:</p>
                <div>
                    <img src="../assets/img/bukti_bayar/<?= htmlspecialchars($o['bukti_bayar']); ?>"
                        alt="Bukti Pembayaran"
                        class="img-fluid rounded border shadow-sm"
                        style="max-width: 350px; max-height: 450px; object-fit: contain;">
                </div>
            </div>
        <?php endif; ?>

    </div>

</body>

</html>