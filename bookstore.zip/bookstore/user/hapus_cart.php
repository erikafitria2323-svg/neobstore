<?php
/**
 * Menghapus item tertentu dari keranjang milik pengguna yang sedang login.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

// Pengecekan autentikasi user
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login.php");
    exit;
}

$id_user = $_SESSION['id_user'];
$id_cart = mysqli_real_escape_string($conn, $_GET['id']);

// Hapus item keranjang berdasarkan id_cart dan id_user
mysqli_query($conn, "
    DELETE FROM cart
    WHERE id_cart = '$id_cart'
    AND id_user = '$id_user'
");

header("Location: cart.php");
exit;