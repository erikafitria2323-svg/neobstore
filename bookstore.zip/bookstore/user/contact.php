<?php
/**
 * Menampilkan informasi kontak dan memproses pesan yang dikirim pelanggan kepada admin.
 */
session_start(); 
include __DIR__ . "/../config/koneksi.php"; 

$loggedIn = isset($_SESSION['id_user']);

if ($loggedIn && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['kirim'])) {
    $id_user = $_SESSION['id_user'];
    $pesan = trim($_POST['pesan']);
    
    if ($pesan !== '') {
        $stmt = mysqli_prepare($conn, "INSERT INTO pesan (id_user,pesan,tanggal) VALUES (?,?,NOW())");
        mysqli_stmt_bind_param($stmt, 'is', $id_user, $pesan);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        
        $_SESSION['info'] = [
            'type' => 'success',
            'message' => 'Pesan berhasil dikirim ke Admin NEO BSTORE.'
        ];
    } else {
        $_SESSION['info'] = [
            'type' => 'danger',
            'message' => 'Pesan tidak boleh kosong.'
        ];
    }
    
    header('Location: contact.php');
    exit;
}

$riwayat = false;
if ($loggedIn) {
    $id_user = $_SESSION['id_user'];
    $riwayat = mysqli_query($conn, "SELECT * FROM pesan WHERE id_user='$id_user' ORDER BY tanggal DESC");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>Hubungi Admin - NEO BSTORE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="d-flex min-vh-100">
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
            </div>
            <nav class="sidebar-nav">
                <a href="../index.php"><i class="bi bi-house-door-fill"></i><span>Beranda</span></a>
                <a href="kategori.php"><i class="bi bi-bar-chart-steps"></i><span>Kategori</span></a>
                <a href="cart.php"><i class="bi bi-cart3"></i><span>Keranjang</span></a>
                <a href="pesanan.php"><i class="bi bi-box-seam"></i><span>Pesanan Saya</span></a>
                <a href="about.php"><i class="bi bi-info-circle"></i><span>Tentang Kami</span></a>
                <a href="contact.php" class="active"><i class="bi bi-chat-dots"></i><span>Hubungi Admin</span></a>
                <?php if ($loggedIn): ?>
                    <a href="../logout.php" class="text-danger mt-auto"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a>
                <?php else: ?>
                    <a href="../login.php" class="text-primary mt-auto"><i class="bi bi-box-arrow-in-right"></i><span>Login / Daftar</span></a>
                <?php endif; ?>
            </nav>
        </aside>

        <main class="content-wrapper">
            <div class="mb-4">
                <h3 class="fw-bold">Hubungi Admin</h3>
                <p class="text-muted small">Hubungi admin jika ada pertanyaan, kendala, atau saran.</p>
            </div>

            <div class="row g-4">
                <div class="col-lg-7">
                    <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                        <h5 class="fw-bold mb-3">Kirim Pesan</h5>
                        
                        <?php if (isset($_SESSION['info'])): ?>
                            <div class="alert alert-<?=htmlspecialchars($_SESSION['info']['type']);?>">
                                <?=htmlspecialchars($_SESSION['info']['message']);?>
                            </div>
                            <?php unset($_SESSION['info']); ?>
                        <?php endif; ?>

                        <?php if ($loggedIn): ?>
                            <form method="POST">
                                <textarea name="pesan" class="form-control mb-3" rows="5" placeholder="Tuliskan pertanyaan, kendala, atau saran..." required></textarea>
                                <button name="kirim" class="btn btn-primary rounded-pill px-4">
                                    <i class="bi bi-send me-1"></i>Kirim Pesan
                                </button>
                            </form>
                        <?php else: ?>
                            <p class="text-muted">Login terlebih dahulu untuk mengirim pesan dan melihat balasan admin.</p>
                            <a href="../login.php" class="btn btn-primary rounded-pill px-4">Login</a> 
                            <a href="../register.php" class="btn btn-outline-primary rounded-pill px-4">Daftar</a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-lg-5">
                    <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                        <h5 class="fw-bold mb-3">Informasi Admin</h5>
                        <p class="text-muted small">Gunakan halaman ini untuk menghubungi pengelola NEO BSTORE. Pesan yang dikirim akan masuk ke panel admin.</p>
                        <div class="d-flex gap-3">
                            <i class="bi bi-clock fs-4 text-primary"></i>
                            <div>
                                <strong>Respon Admin</strong>
                                <p class="text-muted small mb-0">Balasan dapat dilihat kembali melalui halaman ini.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($loggedIn): ?>
                <div class="card border-0 shadow-sm rounded-4 p-4 mt-4 bg-white">
                    <h5 class="fw-bold mb-3">Riwayat Pesan & Balasan</h5>
                    <?php if ($riwayat && mysqli_num_rows($riwayat) > 0): ?>
                        <?php while ($r = mysqli_fetch_assoc($riwayat)): ?>
                            <div class="border rounded-3 p-3 mb-3">
                                <small class="text-muted"><?=date('d M Y, H:i', strtotime($r['tanggal']));?> WIB</small>
                                <p class="mb-2 mt-2">
                                    <strong>Pesan Anda:</strong><br>
                                    <?=nl2br(htmlspecialchars($r['pesan']));?>
                                </p>
                                <?php if (!empty($r['balasan'])): ?>
                                    <div class="bg-primary-subtle p-3 rounded-3">
                                        <strong class="text-primary">Balasan Admin:</strong><br>
                                        <?=nl2br(htmlspecialchars($r['balasan']));?>
                                    </div>
                                <?php else: ?>
                                    <span class="badge bg-warning text-dark">Menunggu Balasan</span>
                                <?php endif; ?>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="text-muted mb-0">Belum ada riwayat pesan.</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>