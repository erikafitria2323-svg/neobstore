<?php
/**
 * Form pengajuan pengembalian barang dengan bukti video/foto unboxing.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";
if (!isset($_SESSION['id_user'])) {
    header("Location: ../login.php");
    exit;
}

// Menambahkan kolom khusus proses pengembalian jika belum tersedia.
$kolom_pengembalian = [
    'bukti_unboxing' => "ALTER TABLE pesanan ADD bukti_unboxing VARCHAR(255) NULL",
];
foreach ($kolom_pengembalian as $nama_kolom => $sql_tambah) {
    $cek_kolom = mysqli_query($conn, "SHOW COLUMNS FROM pesanan LIKE '$nama_kolom'");
    if ($cek_kolom && mysqli_num_rows($cek_kolom) === 0) {
        mysqli_query($conn, $sql_tambah);
    }
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$uid = intval($_SESSION['id_user']);
$stmt = mysqli_prepare($conn, "SELECT status FROM pesanan WHERE id_pesanan=? AND id_user=?");
mysqli_stmt_bind_param($stmt, 'ii', $id, $uid);
mysqli_stmt_execute($stmt);
$pesanan = mysqli_stmt_get_result($stmt)->fetch_assoc();
if (!$pesanan || $pesanan['status'] !== 'Diterima') {
    header("Location: pesanan.php");
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_FILES['bukti_unboxing']) || $_FILES['bukti_unboxing']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Silakan pilih bukti unboxing terlebih dahulu.';
    } else {
        $tmp = $_FILES['bukti_unboxing']['tmp_name'];
        $mime = mime_content_type($tmp);
        $allowed = ['image/jpeg'=>'jpg', 'image/png'=>'png', 'image/webp'=>'webp', 'video/mp4'=>'mp4', 'video/quicktime'=>'mov'];
        if (!isset($allowed[$mime]) || $_FILES['bukti_unboxing']['size'] > 20000000) {
            $error = 'Format harus JPG, PNG, WEBP, MP4, atau MOV dengan ukuran maksimal 20 MB.';
        } else {
            $dir = __DIR__ . '/../assets/img/bukti_pengembalian/';
            if (!is_dir($dir)) mkdir($dir, 0775, true);
            $nama = 'unboxing_' . $id . '_' . time() . '.' . $allowed[$mime];
            if (move_uploaded_file($tmp, $dir . $nama)) {
                $status = 'Pengajuan Pengembalian';
                $up = mysqli_prepare($conn, "UPDATE pesanan SET bukti_unboxing=?, status=? WHERE id_pesanan=? AND id_user=?");
                mysqli_stmt_bind_param($up, 'ssii', $nama, $status, $id, $uid);
                mysqli_stmt_execute($up);
                header("Location: pesanan.php");
                exit;
            } else {
                $error = 'Bukti gagal diunggah. Silakan coba lagi.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ajukan Pengembalian - NEO BSTORE</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5" style="max-width:600px">
<div class="card border-0 shadow-sm rounded-4 p-4">
<h4 class="fw-bold mb-2">Ajukan Pengembalian #<?= $id; ?></h4>
<p class="text-muted">Unggah bukti foto atau video unboxing yang menunjukkan kendala pada barang yang diterima.</p>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error); ?></div><?php endif; ?>
<form method="POST" enctype="multipart/form-data">
<label class="form-label fw-semibold">Bukti Unboxing</label>
<input type="file" name="bukti_unboxing" class="form-control mb-2" accept="image/jpeg,image/png,image/webp,video/mp4,video/quicktime" required>
<div class="form-text mb-4">Format JPG, PNG, WEBP, MP4, atau MOV. Maksimal 20 MB.</div>
<button class="btn btn-danger rounded-pill px-4" type="submit">Kirim Pengajuan</button>
<a href="pesanan.php" class="btn btn-outline-secondary rounded-pill">Batal</a>
</form>
</div></div></body></html>
