<?php
/**
 * Menampilkan halaman utama pelanggan yang berisi katalog buku dan fitur pencarian atau penyaringan.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";


if (!defined('BASE_URL')) {
    $scriptPath = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
    if (basename($scriptPath) === 'index.php') {
        $baseUrl = rtrim(dirname($scriptPath), '/');
    } else {
        $baseUrl = preg_replace('~/user/[^/]+$~', '', $scriptPath);
    }
    if ($baseUrl === '' || $baseUrl === '/') {
        $baseUrl = '';
    }
    define('BASE_URL', rtrim($baseUrl, '/'));
}

$homeUrl = BASE_URL . '/index.php';
$userUrl = BASE_URL . '/user/';
$authUrl = BASE_URL . '/';
$assetPrefix = BASE_URL . '/assets/';

// Fungsi Pemetaan Ikon & Warna Kategori
// Menentukan ikon dan warna tampilan yang sesuai dengan nama kategori buku.
function getCategoryStyle($nama)
{
    $nama_clean = strtolower(trim($nama));

    if (strpos($nama_clean, 'novel') !== false) {
        return ['icon' => 'bi-book', 'bg' => '#FFEAD2', 'color' => '#E07A5F'];
    } elseif (strpos($nama_clean, 'komik') !== false) {
        return ['icon' => 'bi-chat-left-text', 'bg' => '#E0F4FE', 'color' => '#0284C7'];
    } elseif (strpos($nama_clean, 'bisnis') !== false) {
        return ['icon' => 'bi-briefcase', 'bg' => '#F3E8FF', 'color' => '#9333EA'];
    } elseif (strpos($nama_clean, 'pendidikan') !== false) {
        return ['icon' => 'bi-compass', 'bg' => '#DCFCE7', 'color' => '#16A34A'];
    } elseif (strpos($nama_clean, 'pengembangan diri') !== false) {
        return ['icon' => 'bi-tree', 'bg' => '#FDF4AF', 'color' => '#CA8A04'];
    } elseif (strpos($nama_clean, 'sejarah') !== false) {
        return ['icon' => 'bi-folder', 'bg' => '#E5E7EB', 'color' => '#4B5563'];
    } elseif (strpos($nama_clean, 'agama') !== false) {
        return ['icon' => 'bi-moon-stars', 'bg' => '#E2E8F0', 'color' => '#334155'];
    } elseif (strpos($nama_clean, 'teknologi') !== false) {
        return ['icon' => 'bi-cpu', 'bg' => '#E2E8F0', 'color' => '#334155'];
    }

    return ['icon' => 'bi-bookmark', 'bg' => '#F1F5F9', 'color' => '#64748B'];
}

$kategori_query = mysqli_query($conn, "SELECT * FROM kategori LIMIT 4");

// Filter Pencarian & Kategori
$keyword = isset($_GET['keyword']) ? mysqli_real_escape_string($conn, $_GET['keyword']) : '';
$kat_filter = isset($_GET['kategori']) ? mysqli_real_escape_string($conn, $_GET['kategori']) : '';

$sql = "SELECT buku.*, kategori.nama_kategori 
        FROM buku 
        JOIN kategori ON buku.id_kategori = kategori.id_kategori 
        WHERE 1=1";

if (!empty($keyword)) {
    $sql .= " AND (buku.judul LIKE '%$keyword%' OR buku.penulis LIKE '%$keyword%' OR kategori.nama_kategori LIKE '%$keyword%')";
}

if (!empty($kat_filter)) {
    $sql .= " AND buku.id_kategori = '$kat_filter'";
}

$sql .= " ORDER BY buku.id_buku DESC"; 
$buku = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NEO BSTORE - Toko Buku Online</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom Style -->
    <link rel="stylesheet" href="<?= $assetPrefix ?>css/style.css">
</head>

<body>

    <div class="d-flex min-vh-100">

        <!-- Sidebar Left -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
            </div>

            <nav class="sidebar-nav">
                <a href="<?= $homeUrl ?>" class="<?= (empty($kat_filter) && empty($keyword)) ? 'active' : '' ?>">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Beranda</span>
                </a>
                <a href="<?= $userUrl ?>kategori.php">
                    <i class="bi bi-bar-chart-steps"></i>
                    <span>Kategori</span>
                </a>
                <a href="<?= $userUrl . 'cart.php'; ?>">
                    <i class="bi bi-cart3"></i>
                    <span>Keranjang</span>
                </a>
                <a href="<?= $userUrl . 'pesanan.php'; ?>">
                    <i class="bi bi-box-seam"></i>
                    <span>Pesanan Saya</span>
                </a>
                <a href="<?= $userUrl ?>about.php">
                    <i class="bi bi-info-circle"></i>
                    <span>Tentang Kami</span>
                </a>
                <a href="<?= $userUrl ?>contact.php">
                    <i class="bi bi-chat-dots"></i>
                    <span>Hubungi Admin</span>
                </a>
                <?php if (isset($_SESSION['id_user'])): ?>
                    <a href="<?= $authUrl ?>logout.php" class="text-danger mt-auto">
                        <i class="bi bi-box-arrow-right"></i>
                        <span>Logout</span>
                    </a>
                <?php else: ?>
                    <a href="<?= $authUrl ?>login.php" class="text-primary mt-auto">
                        <i class="bi bi-box-arrow-in-right"></i>
                        <span>Login / Daftar</span>
                    </a>
                <?php endif; ?>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="content-wrapper">

            <!-- Top Search Bar -->
            <div class="search-container mb-4">
                <form method="GET" action="<?= $homeUrl ?>#rekomendasi" class="position-relative">
                    <input type="text" name="keyword" class="form-control search-input" placeholder="Cari Buku..." value="<?= htmlspecialchars($keyword); ?>">
                    <button type="submit" class="search-btn">
                        <i class="bi bi-search"></i>
                    </button>
                </form>
            </div>

            <!-- Banner Promo -->
            <div class="banner mb-4">
                <div class="banner-text">
                    <h1>Diskon Spesial<br>Buku Pilihan</h1>
                    <p>Diskon hingga 30% untuk buku pilihan</p>
                    <a href="#rekomendasi" class="btn-belanja-now">Belanja Sekarang</a>
                </div>
            </div>

            <!-- Kategori Populer Section -->
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold section-title mb-0">Kategori Buku</h5>
                <a href="<?= $userUrl ?>kategori.php" class="see-all-link">Lihat Semua</a>
            </div>

            <!-- Pas 5 Item dalam 1 Baris Sejajar -->
            <div class="row row-cols-5 g-3 mb-5 text-center align-items-center">
                <?php
                while ($kat = mysqli_fetch_assoc($kategori_query)) {
                    $style = getCategoryStyle($kat['nama_kategori']);
                    $is_active = ($kat_filter == $kat['id_kategori']);
                ?>
                    <div class="col">
                        <!-- Diklik menyaring buku di beranda -->
                        <a href="<?= $homeUrl ?>?kategori=<?= $kat['id_kategori']; ?>#rekomendasi" class="kat-card <?= $is_active ? 'active-kat' : '' ?>">
                            <div class="kat-icon-box" style="background-color: <?= $style['bg']; ?>; color: <?= $style['color']; ?>;">
                                <i class="bi <?= $style['icon']; ?>"></i>
                            </div>
                            <span class="kat-name"><?= htmlspecialchars($kat['nama_kategori']); ?></span>
                        </a>
                    </div>
                <?php } ?>


                <div class="col">
                    <a href="<?= $userUrl ?>kategori.php" class="kat-card">
                        <div class="kat-icon-box" style="background-color: #E2E8F0; color: #475569;">
                            <i class="bi bi-grid-3x3-gap"></i>
                        </div>
                        <span class="kat-name">Lainnya</span>
                    </a>
                </div>
            </div>

            <!-- Rekomendasi Buku Section -->
            <div class="d-flex justify-content-between align-items-center mb-3" id="rekomendasi">
                <h5 class="fw-bold section-title mb-0">
                    <?= !empty($kat_filter) ? 'Hasil Filter Kategori' : (!empty($keyword) ? 'Hasil Pencarian' : 'Rekomendasi Buku') ?>
                </h5>
                <?php if (!empty($kat_filter) || !empty($keyword)): ?>
                    <a href="<?= $homeUrl ?>#rekomendasi" class="btn btn-sm btn-outline-secondary rounded-pill">
                        <i class="bi bi-x-circle me-1"></i> Reset Filter
                    </a>
                <?php endif; ?>
            </div>

            <!-- Grid Card Buku -->
            <div class="row g-4">
                <?php if (mysqli_num_rows($buku) > 0) { ?>
                    <?php while ($b = mysqli_fetch_assoc($buku)) { ?>
                        <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                            <div class="card book-card-modern h-100 shadow-sm">
                                <div class="book-img-wrapper">
                                    <img src="<?= $assetPrefix ?>img/buku/<?= $b['gambar']; ?>" class="card-img-top" alt="<?= htmlspecialchars($b['judul']); ?>" onerror="this.src='https://via.placeholder.com/200x260?text=No+Cover'">
                                </div>

                                <div class="card-body p-3 d-flex flex-column text-center">
                                    <h6 class="fw-bold mb-1 book-title"><?= htmlspecialchars($b['judul']); ?></h6>
                                    <small class="text-muted d-block mb-2"><?= htmlspecialchars($b['penulis']); ?></small>

                                    <div class="mb-2">
                                        <span class="badge bg-primary-subtle text-primary fw-semibold rounded-pill px-3 py-1">
                                            <?= htmlspecialchars($b['nama_kategori']); ?>
                                        </span>
                                    </div>

                                    <h5 class="fw-bold text-success my-2 fs-6">
                                        Rp <?= number_format($b['harga'], 0, ",", "."); ?>
                                    </h5>

                                    <div class="d-flex gap-2 mt-auto">
                                        <a href="<?= $userUrl ?>detail.php?id=<?= $b['id_buku']; ?>" class="btn btn-outline-primary rounded-3 flex-fill py-2 fw-medium">
                                            <i class="bi bi-eye me-1"></i> Detail
                                        </a>

                                        <?php if ($b['stok'] > 0): ?>
                                            <?php if (isset($_SESSION['id_user'])): ?>
                                                <!-- Jika stok ada dan user sudah login, arahkan ke checkout -->
                                                <a href="<?= $userUrl ?>checkout.php?id_buku=<?= $b['id_buku']; ?>&qty=1" class="btn btn-primary rounded-3 flex-fill py-2 fw-medium" title="Beli Langsung">
                                                    <i class="bi bi-cart-plus"></i>
                                                </a>
                                            <?php else: ?>
                                                <!-- Jika belum login, arahkan ke login -->
                                                <a href="<?= $authUrl ?>login.php?redirect=checkout" class="btn btn-primary rounded-3 flex-fill py-2 fw-medium" onclick="return confirm('Anda harus login terlebih dahulu untuk melakukan pembelian. Login sekarang?');">
                                                    <i class="bi bi-cart-plus"></i>
                                                </a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <!-- Jika stok habis (0), tampilkan tombol mati/disabled -->
                                            <button type="button" class="btn btn-secondary rounded-3 flex-fill py-2 fw-medium" disabled>
                                                Habis
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php } ?>
                <?php } else { ?>
                    <div class="col-12 text-center py-5">
                        <i class="bi bi-journal-x text-muted display-4"></i>
                        <p class="text-muted mt-2">Buku tidak ditemukan pada kategori ini.</p>
                    </div>
                <?php } ?>
            </div>

        </main>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>