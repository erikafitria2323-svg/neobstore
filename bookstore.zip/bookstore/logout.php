<?php
/**
 * Mengakhiri sesi pengguna, menghapus data sesi, dan mengarahkan pengguna kembali ke halaman awal.
 */
session_start();
session_unset();
session_destroy();

// Setelah logout, seluruh pengguna (baik admin maupun user) dikembalikan ke halaman login pusat
header('Location: login.php');
exit;