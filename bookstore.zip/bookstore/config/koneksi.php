<?php
/**
 * Membuat koneksi antara aplikasi PHP dan database MySQL yang digunakan oleh Neo Bookstore.
 */
$host = "localhost";
$user = "root";
$pass = "";
$db   = "bookstore";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
?>