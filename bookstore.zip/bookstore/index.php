<?php
/**
 * Menjadi titik masuk website dan memuat halaman utama katalog Neo Bookstore.
 */
// Halaman utama situs. Tetap berada di index.php, bukan halaman login.
include __DIR__ . '/user/home.php';
