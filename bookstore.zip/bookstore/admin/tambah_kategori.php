<?php
/**
 * Memproses penambahan kategori buku baru ke dalam database.
 */
include __DIR__ . "/../config/koneksi.php";

if (isset($_POST['simpan'])) {

    $kategori = $_POST['kategori'];

    mysqli_query(
        $conn,
        "INSERT INTO kategori(nama_kategori)
        VALUES('$kategori')"
    );

    header("Location: kategori.php");
}
?>

<h2>Tambah Kategori</h2>

<form method="POST">
    Nama Kategori
    <br>
    <input type="text" name="kategori">
    <br><br>
    <button type="submit" name="simpan">
        Simpan
    </button>
</form>