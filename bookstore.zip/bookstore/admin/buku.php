<?php
/**
 * Menampilkan daftar buku yang tersimpan di database serta menyediakan akses untuk menambah, mengubah, dan menghapus data buku.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("Location: login.php");
    exit;
}

$data = mysqli_query($conn, "
    SELECT buku.*, kategori.nama_kategori
    FROM buku
    JOIN kategori ON buku.id_kategori = kategori.id_kategori
    ORDER BY buku.id_buku DESC
");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Buku - Admin NEO BSTORE</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="d-flex min-vh-100 admin-layout">

        <!-- Sidebar Left -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
                <small class="badge bg-danger-subtle text-danger fw-semibold px-2 py-1 mt-1">ADMIN PANEL</small>
            </div>

            <nav class="sidebar-nav">
                <a href="dashboard.php">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Dashboard</span>
                </a>
                <a href="kategori.php">
                    <i class="bi bi-bar-chart-steps"></i>
                    <span>Kategori</span>
                </a>
                <a href="buku.php" class="active">
                    <i class="bi bi-book"></i>
                    <span>Buku</span>
                </a>
                <a href="user.php">
                    <i class="bi bi-people"></i>
                    <span>User</span>
                </a>
                <a href="pesanan.php">
                    <i class="bi bi-box-seam"></i>
                    <span>Pesanan</span>
                </a>
                <a href="pesan.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'pesan.php') ? 'active' : '' ?>">
                    <i class="bi bi-chat-left-text-fill"></i>
                    <span>Pesan Masuk</span>
                </a>
                <a href="tampilan_user.php">
                    <i class="bi bi-shop"></i>
                    <span>Tampilan User</span>
                </a>
                <a href="../logout.php" class="text-danger mt-auto">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Logout</span>
                </a>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="content-wrapper">

            <!-- Page Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold text-dark mb-1">Data Buku</h3>
                    <p class="text-muted small mb-0">Kelola katalog buku yang dijual di toko online</p>
                </div>
                <!-- Diubah dari w-50 menjadi auto/px-4 agar ukurannya pas dengan teksnya -->
                <a href="tambah_buku.php" class="btn btn-lihat-buku rounded-pill px-4">
                    <i class="bi bi-plus-lg me-1"></i> Tambah Buku
                </a>
            </div>

            <!-- Tabel Data Buku -->
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-primary">
                            <tr>
                                <th width="60" class="ps-4">No</th>
                                <th width="90">Gambar</th>
                                <th>Judul Buku</th>
                                <th>Penulis</th>
                                <th>Kategori</th>
                                <th width="120">Harga</th>
                                <th width="90" class="text-center">Stok</th> <!-- Kolom Stok -->
                                <th width="140" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            while ($b = mysqli_fetch_assoc($data)) {
                            ?>
                            <tr>
                                <td class="ps-4 fw-semibold"><?= $no++; ?></td>
                                <td>
                                    <img src="../assets/img/buku/<?= htmlspecialchars($b['gambar']); ?>" class="rounded-3 shadow-sm" width="55" height="70" style="object-fit: cover;" onerror="this.src='https://via.placeholder.com/55x70?text=No+Cover'">
                                </td>
                                <td class="fw-bold text-dark"><?= htmlspecialchars($b['judul']); ?></td>
                                <td class="text-muted"><?= htmlspecialchars($b['penulis']); ?></td>
                                <td>
                                    <span class="badge bg-primary-subtle text-primary fw-semibold rounded-pill px-3 py-1">
                                        <?= htmlspecialchars($b['nama_kategori']); ?>
                                    </span>
                                </td>
                                <td class="fw-bold text-success" style="white-space: nowrap;">
                                    Rp <?= number_format($b['harga'], 0, ",", "."); ?>
                                </td>
                                <!-- Tampilan Stok dengan Badge Kondisi -->
                                 <td class="text-center">
                                    <?php if ($b['stok'] > 0): ?>
                                        <span class="badge bg-success-subtle text-success fw-semibold px-2 py-1"><?= $b['stok']; ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-danger-subtle text-danger fw-semibold px-2 py-1">Habis</span>
                                        <?php endif; ?>
                                 </td>
                                 <td class="text-center">
                                    <a href="edit_buku.php?id=<?= $b['id_buku']; ?>" class="btn btn-warning btn-sm rounded-3 me-1">
                                        <i class="bi bi-pencil-square"></i>
                                    </a>
                                    <a href="hapus_buku.php?id=<?= $b['id_buku']; ?>" class="btn btn-danger btn-sm rounded-3" onclick="return confirm('Hapus buku ini?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>

    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>