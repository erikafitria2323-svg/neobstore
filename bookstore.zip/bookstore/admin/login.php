<?php
/**
 * Memproses autentikasi admin dan membuat sesi agar admin dapat mengakses halaman pengelolaan toko.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

// Cek jika sudah login sebagai admin
if (isset($_SESSION['id_user']) && $_SESSION['role'] === 'admin') {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if (isset($_POST['login'])) {
    $u  = mysqli_real_escape_string($conn, $_POST['username']);
    $pw = $_POST['password'];

    $q = mysqli_query($conn, "SELECT * FROM user WHERE username='$u' AND role='admin'");

    if (mysqli_num_rows($q) === 1) {
        $row = mysqli_fetch_assoc($q);
        
        // Cek plain text atau hash password
        if ($pw === $row['password'] || password_verify($pw, $row['password'])) {
            $_SESSION['id_user'] = $row['id_user'];
            $_SESSION['nama']    = $row['nama'];
            $_SESSION['role']    = 'admin';

            header('Location: dashboard.php');
            exit;
        }
    }
    
    $error = 'Username atau password admin salah.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin - NEO BSTORE</title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        body {
            font-family: Arial, sans-serif;
            min-height: 100vh;
            background: #f8fafc;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .box {
            width: 100%;
            max-width: 420px;
            background: #fff;
            border-radius: 22px;
            padding: 30px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, .08);
        }
    </style>
</head>
<body>

    <div class="box">
        <!-- Header -->
        <div class="text-center mb-4">
            <h3 class="fw-bold">NEO <span class="text-primary">BSTORE</span></h3>
            <span class="badge bg-danger-subtle text-danger">ADMIN PANEL</span>
        </div>

        <!-- Notifikasi Error -->
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <?= htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <!-- Form Login -->
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Username Admin</label>
                <input type="text" name="username" class="form-control" required autocomplete="username">
            </div>
            
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required autocomplete="current-password">
            </div>

            <button type="submit" name="login" class="btn btn-danger w-100 rounded-pill">
                Masuk sebagai Admin
            </button>
        </form>

        <!-- Navigasi Bawah -->
        <div class="text-center mt-3">
            <a href="../login.php" class="small text-decoration-none">← Login User</a>
            <span class="text-muted mx-1">|</span>
            <a href="../index.php" class="small text-decoration-none">Beranda</a>
        </div>
    </div>

</body>
</html>