<?php
/**
 * Mengambil dan menampilkan file bukti pembayaran berdasarkan data pesanan, dengan memeriksa lokasi penyimpanan file.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$q  = mysqli_query($conn, "SELECT bukti_bayar FROM pesanan WHERE id_pesanan = $id");
$p  = mysqli_fetch_assoc($q);
$nama = $p ? basename(trim((string)$p['bukti_bayar'])) : '';

// Cari file di beberapa kemungkinan lokasi (jaga-jaga jika upload tersimpan di folder lain
$root = realpath(__DIR__ . '/..');
$kandidat = [
    $root . '/assets/img/bukti_bayar/' . $nama,
    $root . '/user/assets/img/bukti_bayar/' . $nama,
    $root . '/assets/img/' . $nama,
    $root . '/uploads/' . $nama,
];

$file = null;
if ($nama !== '') {
    foreach ($kandidat as $k) {
        if (is_file($k)) { $file = $k; break; }
    }
}

if ($file) {
    $ext  = strtolower(pathinfo($file, PATHINFO_EXTENSION));
    $mime = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png'][$ext] ?? 'application/octet-stream';
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($file));
    readfile($file);
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bukti Pembayaran</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light d-flex align-items-center justify-content-center min-vh-100">
    <div class="text-center p-4">
        <h5 class="fw-bold">Bukti pembayaran tidak ditemukan</h5>
        <p class="text-muted small mb-1">
            <?= $nama === '' ? 'Pesanan ini belum memiliki bukti pembayaran.' : 'File "' . htmlspecialchars($nama) . '" tidak ada di folder assets/img/bukti_bayar/.'; ?>
        </p>
        <p class="text-muted small">Minta pembeli mengupload ulang bukti pembayarannya.</p>
        <a href="pesanan.php" class="btn btn-secondary btn-sm">Kembali</a>
    </div>
</body>
</html>
