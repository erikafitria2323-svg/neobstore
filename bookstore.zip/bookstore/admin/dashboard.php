<?php
/**
 * Menampilkan halaman dashboard admin beserta ringkasan statistik dan informasi aktivitas toko.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

// Pengecekan Autentikasi Admin
if (!isset($_SESSION['id_user']) || $_SESSION['role'] != "admin") {
    header("Location: ../login.php");
    exit;
}

// Query Ringkasan Data untuk Statistik
$total_buku     = mysqli_num_rows(mysqli_query($conn, "SELECT id_buku FROM buku"));
$total_kategori = mysqli_num_rows(mysqli_query($conn, "SELECT id_kategori FROM kategori"));
$total_user     = mysqli_num_rows(mysqli_query($conn, "SELECT id_user FROM user WHERE role='user'"));
$total_pesanan  = mysqli_num_rows(mysqli_query($conn, "SELECT id_pesanan FROM pesanan"));
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - NEO BSTORE</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="d-flex min-vh-100 admin-layout">

        <!-- Sidebar Left -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
                <small class="badge bg-danger-subtle text-danger fw-semibold px-2 py-1 mt-1">ADMIN PANEL</small>
            </div>

            <nav class="sidebar-nav">
                <a href="dashboard.php" class="active">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Dashboard</span>
                </a>
                <a href="kategori.php">
                    <i class="bi bi-bar-chart-steps"></i>
                    <span>Kategori</span>
                </a>
                <a href="buku.php">
                    <i class="bi bi-book"></i>
                    <span>Buku</span>
                </a>
                <a href="user.php">
                    <i class="bi bi-people"></i>
                    <span>User</span>
                </a>
                <a href="pesanan.php">
                    <i class="bi bi-box-seam"></i>
                    <span>Pesanan</span>
                </a>
                <a href="pesan.php" class="<?= (basename($_SERVER['PHP_SELF']) == 'pesan.php') ? 'active' : '' ?>">
                    <i class="bi bi-chat-left-text-fill"></i>
                    <span>Pesan Masuk</span>
                </a>
                <a href="tampilan_user.php">
                    <i class="bi bi-shop"></i>
                    <span>Lihat Toko</span>
                </a>
                <a href="../logout.php" class="text-danger mt-auto">
                    <i class="bi bi-box-arrow-right"></i>
                    <span>Logout</span>
                </a>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="content-wrapper">
            
            <!-- Page Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold text-dark mb-1">Dashboard Admin</h3>
                    <p class="text-muted small mb-0">Selamat datang kembali, <b><?= htmlspecialchars($_SESSION['nama']); ?></b></p>
                </div>
            </div>

            <!-- Cards Ringkasan Statistik -->
            <div class="row g-4 mb-4">
                
                <!-- Total Buku -->
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="card border-0 shadow-sm rounded-4 p-3" style="background-color: #E0F2FE; color: #0369A1;">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="small mb-1 fw-medium" style="color: #0284C7;">Total Buku</h6>
                                <h3 class="fw-bold m-0"><?= $total_buku; ?></h3>
                            </div>
                            <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background-color: rgba(2, 132, 199, 0.15); width: 48px; height: 48px;">
                                <i class="bi bi-book fs-4" style="color: #0284C7;"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Total Kategori -->
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="card border-0 shadow-sm rounded-4 p-3" style="background-color: #DCFCE7; color: #15803D;">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="small mb-1 fw-medium" style="color: #16A34A;">Total Kategori</h6>
                                <h3 class="fw-bold m-0"><?= $total_kategori; ?></h3>
                            </div>
                            <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background-color: rgba(22, 163, 74, 0.15); width: 48px; height: 48px;">
                                <i class="bi bi-bookmarks fs-4" style="color: #16A34A;"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Total Pelanggan -->
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="card border-0 shadow-sm rounded-4 p-3" style="background-color: #FEF3C7; color: #B45309;">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="small mb-1 fw-medium" style="color: #D97706;">Pelanggan</h6>
                                <h3 class="fw-bold m-0"><?= $total_user; ?></h3>
                            </div>
                            <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background-color: rgba(217, 119, 6, 0.15); width: 48px; height: 48px;">
                                <i class="bi bi-people fs-4" style="color: #D97706;"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Total Pesanan -->
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="card border-0 shadow-sm rounded-4 p-3" style="background-color: #FFE4E6; color: #BE123C;">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="small mb-1 fw-medium" style="color: #E11D48;">Total Pesanan</h6>
                                <h3 class="fw-bold m-0"><?= $total_pesanan; ?></h3>
                            </div>
                            <div class="rounded-3 p-2 d-flex align-items-center justify-content-center" style="background-color: rgba(225, 29, 72, 0.15); width: 48px; height: 48px;">
                                <i class="bi bi-bag-check fs-4" style="color: #E11D48;"></i>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="mb-4">
                <a href="tampilan_user.php" class="btn btn-primary rounded-pill px-4 fw-semibold">
                    <i class="bi bi-shop me-1"></i> Tampilan User
                </a>
            </div>

            <!-- Welcome Card -->
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                <h5 class="fw-bold text-primary mb-2">Selamat Datang di Panel Kelola NEO BSTORE</h5>
                <p class="text-muted m-0">
                    Gunakan menu di sebelah kiri untuk mengelola kategori buku, daftar produk buku, pengguna terdaftar, serta memperbarui status transaksi pesanan.
                </p>
            </div>

        </main>

    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>