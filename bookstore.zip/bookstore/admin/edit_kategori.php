<?php
/**
 * Mengambil data kategori berdasarkan ID dan memproses perubahan nama atau informasi kategori.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("Location: login.php");
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$data = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT *
    FROM kategori
    WHERE id_kategori='$id'
"));

if (!$data) {
    header("Location: kategori.php");
    exit;
}

if (isset($_POST['update'])) {
    $kategori = mysqli_real_escape_string($conn, $_POST['kategori']);

    mysqli_query($conn, "
        UPDATE kategori
        SET nama_kategori='$kategori'
        WHERE id_kategori='$id'
    ");

    header("Location: kategori.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kategori - Admin NEO BSTORE</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="d-flex min-vh-100 admin-layout">

        <!-- Sidebar Left -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
                <small class="badge bg-danger-subtle text-danger fw-semibold px-2 py-1 mt-1">ADMIN PANEL</small>
            </div>

            <nav class="sidebar-nav">
                <a href="dashboard.php"><i class="bi bi-house-door-fill"></i><span>Dashboard</span></a>
                <a href="kategori.php" class="active"><i class="bi bi-bar-chart-steps"></i><span>Kategori</span></a>
                <a href="buku.php"><i class="bi bi-book"></i><span>Buku</span></a>
                <a href="user.php"><i class="bi bi-people"></i><span>User</span></a>
                <a href="pesanan.php"><i class="bi bi-box-seam"></i><span>Pesanan</span></a>
                <a href="pesan.php"><i class="bi bi-chat-left-text-fill"></i><span>Pesan Masuk</span></a>
                <a href="tampilan_user.php"><i class="bi bi-shop"></i><span>Tampilan User</span></a>
                <a href="../logout.php" class="text-danger mt-auto"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="content-wrapper">

            <!-- Page Header -->
            <div class="mb-4">
                <h3 class="fw-bold text-dark mb-1">Edit Kategori</h3>
                <p class="text-muted small mb-0">Perbarui nama kategori buku</p>
            </div>

            <!-- Form Card -->
            <div class="card border-0 shadow-sm rounded-4 p-4 bg-white" style="max-width: 600px;">
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nama Kategori</label>
                        <input type="text" name="kategori" class="form-control rounded-3" value="<?= htmlspecialchars($data['nama_kategori']); ?>" required>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" name="update" class="btn btn-success rounded-pill px-4">
                            <i class="bi bi-check-lg me-1"></i> Update Kategori
                        </button>
                        <a href="kategori.php" class="btn btn-light rounded-pill px-4">
                            Kembali
                        </a>
                    </div>
                </form>
            </div>

        </main>

    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>