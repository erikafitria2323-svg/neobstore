<?php
/**
 * Menampilkan daftar transaksi pelanggan dan menyediakan pengelolaan status pesanan.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("Location: login.php");
    exit;
}

// Proses update status cepat langsung dari halaman pesanan (jika ada form yang dikirim)
if (isset($_POST['update_status_cepat'])) {
    $id_p = mysqli_real_escape_string($conn, $_POST['id_pesanan']);
    $st_baru = mysqli_real_escape_string($conn, $_POST['status_baru']);
    mysqli_query($conn, "UPDATE pesanan SET status='$st_baru' WHERE id_pesanan='$id_p'");
    header("Location: pesanan.php");
    exit;
}

$pesanan = mysqli_query($conn, "
    SELECT pesanan.*,
           user.nama
    FROM pesanan
    JOIN user ON pesanan.id_user = user.id_user
    ORDER BY pesanan.id_pesanan DESC
");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pesanan - Admin NEO BSTORE</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="d-flex min-vh-100 admin-layout">

        <!-- Sidebar Left -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
                <small class="badge bg-danger-subtle text-danger fw-semibold px-2 py-1 mt-1">ADMIN PANEL</small>
            </div>

            <nav class="sidebar-nav">
                <a href="dashboard.php"><i class="bi bi-house-door-fill"></i><span>Dashboard</span></a>
                <a href="kategori.php"><i class="bi bi-bar-chart-steps"></i><span>Kategori</span></a>
                <a href="buku.php"><i class="bi bi-book"></i><span>Buku</span></a>
                <a href="user.php"><i class="bi bi-people"></i><span>User</span></a>
                <a href="pesanan.php" class="active"><i class="bi bi-box-seam"></i><span>Pesanan</span></a>
                <a href="pesan.php"><i class="bi bi-chat-left-text-fill"></i><span>Pesan Masuk</span></a>
                <a href="tampilan_user.php"><i class="bi bi-shop"></i><span>Tampilan User</span></a>
                <a href="../logout.php" class="text-danger mt-auto"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="content-wrapper">

            <!-- Page Header -->
            <div class="mb-4">
                <h3 class="fw-bold text-dark mb-1">Data Pesanan</h3>
                <p class="text-muted small mb-0">Kelola dan update status pesanan dari pembeli dengan cepat</p>
            </div>

            <!-- Tabel Data Pesanan -->
            <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0" style="font-size: 13.5px;">
                        <thead class="table-primary">
                            <tr>
                                <th width="50" class="ps-4">No</th>
                                <th>Pembeli</th>
                                <th class="text-nowrap">Tanggal</th>
                                <th class="text-nowrap">Total</th>
                                <th>Metode</th>
                                <th class="text-center" width="220">Status & Ubah</th>
                                <th class="text-center">Bukti Bayar</th>
                                <th width="100" class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            while ($p = mysqli_fetch_assoc($pesanan)) {
                                $status = trim((string)$p['status']) !== '' ? $p['status'] : 'Menunggu Pembayaran';
                            ?>
                                <tr>
                                    <td class="ps-4 fw-semibold"><?= $no++; ?></td>
                                    <td class="fw-bold text-dark"><?= htmlspecialchars($p['nama']); ?></td>
                                    <td class="text-nowrap"><?= date('d M Y, H:i', strtotime($p['tanggal'])); ?></td>
                                    <td class="fw-bold text-success text-nowrap">Rp <?= number_format($p['total'], 0, ",", "."); ?></td>
                                    <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($p['metode_pembayaran']); ?></span></td>
                                    
                                    <!-- Kolom Ubah Status Langsung via Dropdown -->
                                    <td class="text-center">
                                        <form method="POST" class="d-flex align-items-center gap-1">
                                            <input type="hidden" name="id_pesanan" value="<?= $p['id_pesanan']; ?>">
                                            <select name="status_baru" class="form-select form-select-sm text-xs rounded-3">
                                                <option value="Menunggu Pembayaran" <?= $status == "Menunggu Pembayaran" ? "selected" : ""; ?>>Menunggu Pembayaran</option>
                                                <option value="Menunggu Verifikasi" <?= $status == "Menunggu Verifikasi" ? "selected" : ""; ?>>Menunggu Verifikasi</option>
                                                <option value="Diproses" <?= $status == "Diproses" ? "selected" : ""; ?>>Diproses</option>
                                                <option value="Dikirim" <?= $status == "Dikirim" ? "selected" : ""; ?>>Dikirim</option>
                                                <option value="Diterima" <?= $status == "Diterima" ? "selected" : ""; ?>>Diterima</option>
                                                <option value="Pengajuan Pengembalian" <?= $status == "Pengajuan Pengembalian" ? "selected" : ""; ?>>Pengajuan Pengembalian</option>
                                                <option value="Pengembalian Disetujui" <?= $status == "Pengembalian Disetujui" ? "selected" : ""; ?>>Pengembalian Disetujui</option>
                                                <option value="Menunggu Barang Dikembalikan" <?= $status == "Menunggu Barang Dikembalikan" ? "selected" : ""; ?>>Menunggu Barang Dikembalikan</option>
                                                <option value="Dana Dikembalikan" <?= $status == "Dana Dikembalikan" ? "selected" : ""; ?>>Dana Dikembalikan</option>
                                                <option value="Selesai" <?= $status == "Selesai" ? "selected" : ""; ?>>Selesai</option>
                                            </select>
                                            <button type="submit" name="update_status_cepat" class="btn btn-primary btn-sm rounded-3 px-2" title="Simpan Status">
                                                <i class="bi bi-check-lg"></i>
                                            </button>
                                        </form>
                                    </td>

                                    <td class="text-center">
                                        <?php if (!empty($p['bukti_bayar'])): ?>
                                            <button type="button" class="btn btn-outline-success btn-sm rounded-3" 
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#modalBukti" 
                                                    data-imgsrc="bukti.php?id=<?= $p['id_pesanan']; ?>"
                                                    data-idpesanan="<?= $p['id_pesanan']; ?>">
                                                <i class="bi bi-receipt"></i> Lihat
                                            </button>
                                        <?php else: ?>
                                            <span class="text-muted small">Tidak ada</span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="text-center">
                                        <a href="detail_pesanan.php?id=<?= $p['id_pesanan']; ?>" class="btn btn-info btn-sm rounded-3 text-white" title="Detail Pesanan">
                                            <i class="bi bi-eye"></i> Detail
                                        </a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>

    <!-- Modal Popup Bukti Pembayaran -->
    <div class="modal fade" id="modalBukti" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md">
            <div class="modal-content rounded-4 border-0 shadow">
                <div class="modal-header border-bottom-0">
                    <h5 class="modal-title fw-bold">Bukti Pembayaran Pesanan #<span id="labelIdPesanan"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center bg-light p-3">
                    <img id="imgBuktiPreview" src="" alt="Bukti Pembayaran" class="img-fluid rounded border shadow-sm" style="max-height: 500px; object-fit: contain;">
                </div>
                <div class="modal-footer border-top-0 justify-content-center">
                    <button type="button" class="btn btn-secondary btn-sm rounded-pill px-4" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS & Modal Script -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const modalBukti = document.getElementById('modalBukti');
        if (modalBukti) {
            modalBukti.addEventListener('show.bs.modal', function (event) {
                const button = event.relatedTarget;
                modalBukti.querySelector('#labelIdPesanan').textContent = button.getAttribute('data-idpesanan');
                modalBukti.querySelector('#imgBuktiPreview').src = button.getAttribute('data-imgsrc');
            });
        }
    </script>
</body>
</html>