<?php
/**
 * Mengambil dan menampilkan informasi lengkap suatu pesanan, data pelanggan, rincian buku, dan bukti pembayaran.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";

// Menambahkan kolom khusus proses pengembalian jika belum tersedia.
$kolom_pengembalian = [
    'bukti_unboxing' => "ALTER TABLE pesanan ADD bukti_unboxing VARCHAR(255) NULL",
];
foreach ($kolom_pengembalian as $nama_kolom => $sql_tambah) {
    $cek_kolom = mysqli_query($conn, "SHOW COLUMNS FROM pesanan LIKE '$nama_kolom'");
    if ($cek_kolom && mysqli_num_rows($cek_kolom) === 0) {
        mysqli_query($conn, $sql_tambah);
    }
}


if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Admin memverifikasi pengajuan dan mengonfirmasi barang retur telah diterima.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi_pengembalian'])) {
    $aksi = $_POST['aksi_pengembalian'];
    $status_baru = null;
    if ($aksi === 'setujui') $status_baru = 'Pengembalian Disetujui';
    if ($aksi === 'barang_sampai') $status_baru = 'Dana Dikembalikan';
    if ($status_baru !== null) {
        $up = mysqli_prepare($conn, "UPDATE pesanan SET status=? WHERE id_pesanan=?");
        mysqli_stmt_bind_param($up, 'si', $status_baru, $id);
        mysqli_stmt_execute($up);
        header("Location: detail_pesanan.php?id=" . $id);
        exit;
    }
}


// Ambil info pesanan & pembeli (ditambahkan JOIN dengan kolom alamat dan no_hp dari tabel user)
$info_q = mysqli_query($conn, "
    SELECT pesanan.*, user.nama, user.email, user.alamat, user.no_hp 
    FROM pesanan 
    JOIN user ON pesanan.id_user = user.id_user 
    WHERE pesanan.id_pesanan = '$id'
");
$pesanan_info = mysqli_fetch_assoc($info_q);

if (!$pesanan_info) {
    header("Location: pesanan.php");
    exit;
}

// Ambil item produk dalam pesanan
$data = mysqli_query($conn, "
    SELECT detail_pesanan.*, buku.judul, buku.gambar
    FROM detail_pesanan
    JOIN buku ON detail_pesanan.id_buku = buku.id_buku
    WHERE detail_pesanan.id_pesanan = '$id'
");
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pesanan #<?= $id; ?> - Admin NEO BSTORE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

    <div class="d-flex min-vh-100 admin-layout">

        <!-- Sidebar Left -->
        <aside class="sidebar-wrapper">
            <div class="sidebar-brand">
                <h3 class="logo-text">NEO <span>BSTORE</span></h3>
                <small class="badge bg-danger-subtle text-danger fw-semibold px-2 py-1 mt-1">ADMIN PANEL</small>
            </div>

            <nav class="sidebar-nav">
                <a href="dashboard.php"><i class="bi bi-house-door-fill"></i><span>Dashboard</span></a>
                <a href="kategori.php"><i class="bi bi-bar-chart-steps"></i><span>Kategori</span></a>
                <a href="buku.php"><i class="bi bi-book"></i><span>Buku</span></a>
                <a href="user.php"><i class="bi bi-people"></i><span>User</span></a>
                <a href="pesanan.php" class="active"><i class="bi bi-box-seam"></i><span>Pesanan</span></a>
                <a href="pesan.php"><i class="bi bi-chat-left-text-fill"></i><span>Pesan Masuk</span></a>
                <a href="tampilan_user.php"><i class="bi bi-shop"></i><span>Tampilan User</span></a>
                <a href="../logout.php" class="text-danger mt-auto"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a>
            </nav>
        </aside>

        <!-- Main Content Area -->
        <main class="content-wrapper">

            <!-- Page Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold text-dark mb-1">Detail Pesanan #<?= $id; ?></h3>
                    <p class="text-muted small mb-0">Rincian produk dan informasi transaksi pembeli</p>
                </div>
                <a href="pesanan.php" class="btn btn-outline-secondary rounded-pill px-4">
                    <i class="bi bi-arrow-left me-1"></i> Kembali
                </a>
            </div>

            <div class="row g-4">
                <!-- Informasi Transaksi & Produk -->
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm rounded-4 p-4 bg-white mb-4">
                        <h5 class="fw-bold mb-3"><i class="bi bi-info-circle me-2 text-primary"></i>Informasi Pembeli & Pengiriman</h5>
                        <div class="row g-3">
                            <div class="col-sm-6">
                                <span class="text-muted small d-block">Nama Pembeli</span>
                                <strong class="text-dark"><?= htmlspecialchars($pesanan_info['nama']); ?></strong>
                            </div>
                            <div class="col-sm-6">
                                <span class="text-muted small d-block">Tanggal Transaksi</span>
                                <strong class="text-dark"><?= date('d M Y, H:i', strtotime($pesanan_info['tanggal'])); ?></strong>
                            </div>
                            <div class="col-sm-6">
                                <span class="text-muted small d-block">No. HP / WhatsApp</span>
                                <strong class="text-dark"><?= !empty($pesanan_info['no_hp']) ? htmlspecialchars($pesanan_info['no_hp']) : '<span class="text-muted fst-italic">Belum diisi</span>'; ?></strong>
                            </div>
                            <div class="col-sm-6">
                                <span class="text-muted small d-block">Metode Pembayaran</span>
                                <span class="badge bg-light text-dark border mt-1"><?= htmlspecialchars($pesanan_info['metode_pembayaran']); ?></span>
                            </div>
                            <div class="col-12">
                                <span class="text-muted small d-block">Alamat Pengiriman</span>
                                <div class="p-2 bg-light rounded border mt-1 text-dark">
                                    <?= !empty($pesanan_info['alamat']) ? nl2br(htmlspecialchars($pesanan_info['alamat'])) : '<span class="text-danger fst-italic">Alamat belum diisi oleh pelanggan.</span>'; ?>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <span class="text-muted small d-block">Status Pesanan</span>
                                <span class="badge bg-primary-subtle text-primary rounded-pill px-3 py-1 mt-1 fw-semibold">
                                    <?= htmlspecialchars($pesanan_info['status']); ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Tabel Produk -->
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden bg-white">
                        <div class="card-header bg-white py-3">
                            <h5 class="fw-bold mb-0"><i class="bi bi-bag-check me-2 text-primary"></i>Daftar Buku yang Dibeli</h5>
                        </div>
                        <div class="table-responsive">
                            <table class="table align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th width="70" class="ps-4">Cover</th>
                                        <th>Judul Buku</th>
                                        <th class="text-center">Jumlah</th>
                                        <th>Harga Satuan</th>
                                        <th class="text-end pe-4">Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($d = mysqli_fetch_assoc($data)) { ?>
                                        <tr>
                                            <td class="ps-4">
                                                <img src="../assets/img/buku/<?= htmlspecialchars($d['gambar']); ?>" width="45" height="60" class="rounded shadow-sm" style="object-fit: cover;" onerror="this.src='https://via.placeholder.com/45x60?text=No+Cover'">
                                            </td>
                                            <td class="fw-bold text-dark"><?= htmlspecialchars($d['judul']); ?></td>
                                            <td class="text-center"><?= $d['jumlah']; ?></td>
                                            <td>Rp <?= number_format($d['harga'], 0, ",", "."); ?></td>
                                            <td class="text-end pe-4 fw-bold text-success">Rp <?= number_format($d['harga'] * $d['jumlah'], 0, ",", "."); ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                                <tfoot class="table-light">
                                    <tr>
                                        <td colspan="4" class="text-end fw-bold ps-4">Total Keseluruhan:</td>
                                        <td class="text-end pe-4 fw-bold text-success fs-5">Rp <?= number_format($pesanan_info['total'], 0, ",", "."); ?></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Bukti Pembayaran Card -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4 p-4 bg-white">
                        <h5 class="fw-bold mb-3"><i class="bi bi-receipt me-2 text-primary"></i>Bukti Pembayaran</h5>
                        <?php if (!empty($pesanan_info['bukti_bayar'])): ?>
                            <div class="text-center bg-light p-3 rounded-4 border">
                                <img src="bukti.php?id=<?= intval($id); ?>" class="img-fluid rounded shadow-sm" style="max-height: 350px; object-fit: contain;">
                            </div>
                        <?php else: ?>
                            <div class="alert alert-secondary small mb-0 text-center py-4">
                                <i class="bi bi-info-circle display-6 d-block mb-2"></i>
                                Tidak ada bukti pembayaran (Pesanan menggunakan metode COD atau belum diunggah).
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if (!empty($pesanan_info['bukti_unboxing'])): ?>
                        <div class="card border-0 shadow-sm rounded-4 p-4 bg-white mt-4">
                            <h5 class="fw-bold mb-3"><i class="bi bi-arrow-counterclockwise me-2 text-danger"></i>Bukti Pengajuan Pengembalian</h5>
                            <?php
                                $file_unboxing = $pesanan_info['bukti_unboxing'];
                                $ext_unboxing = strtolower(pathinfo($file_unboxing, PATHINFO_EXTENSION));
                                $url_unboxing = "../assets/img/bukti_pengembalian/" . rawurlencode($file_unboxing);
                            ?>
                            <?php if (in_array($ext_unboxing, ['mp4', 'mov'])): ?>
                                <video src="<?= htmlspecialchars($url_unboxing); ?>" controls class="w-100 rounded"></video>
                            <?php else: ?>
                                <a href="<?= htmlspecialchars($url_unboxing); ?>" target="_blank">
                                    <img src="<?= htmlspecialchars($url_unboxing); ?>" alt="Bukti unboxing" class="img-fluid rounded border">
                                </a>
                            <?php endif; ?>
                            <p class="small text-muted mt-2 mb-3">Periksa bukti unboxing sebelum menyetujui pengembalian.</p>
                            <?php if ($pesanan_info['status'] === 'Pengajuan Pengembalian'): ?>
                                <form method="POST" onsubmit="return confirm('Setujui pengajuan pengembalian ini?')">
                                    <button type="submit" name="aksi_pengembalian" value="setujui" class="btn btn-danger w-100">Setujui Pengembalian</button>
                                </form>
                            <?php elseif ($pesanan_info['status'] === 'Menunggu Barang Dikembalikan'): ?>
                                <form method="POST" onsubmit="return confirm('Konfirmasi barang retur sudah sampai dan proses pengembalian dana?')">
                                    <button type="submit" name="aksi_pengembalian" value="barang_sampai" class="btn btn-success w-100">Barang Sampai & Konfirmasi Pengembalian Dana</button>
                                </form>
                            <?php elseif ($pesanan_info['status'] === 'Pengembalian Disetujui'): ?>
                                <div class="alert alert-info small mb-0">Menunggu user mengirimkan kembali barang.</div>
                            <?php elseif ($pesanan_info['status'] === 'Dana Dikembalikan'): ?>
                                <div class="alert alert-success small mb-0">Barang telah diterima admin dan pengembalian dana telah dikonfirmasi.</div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        </main>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>