<?php
/**
 * Memproses perubahan status pesanan berdasarkan tindakan admin yang dikirim melalui formulir.
 */
session_start();
include __DIR__ . "/../config/koneksi.php";
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') { header("Location: login.php"); exit; }

$id = $_GET['id'];

$data = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT *
    FROM pesanan
    WHERE id_pesanan='$id'
"));

if (isset($_POST['update'])) {

    $status = $_POST['status'];

    mysqli_query($conn, "
        UPDATE pesanan
        SET status='$status'
        WHERE id_pesanan='$id'
    ");

    header("Location:pesanan.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <title>Ubah Status</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container py-5">
        <h2>Ubah Status Pesanan</h2>

        <form method="POST">
            <div class="mb-3">
                <label>Status</label>
                <select name="status" class="form-control">
                    <option value="Menunggu Pembayaran" <?= $data['status'] == "Menunggu Pembayaran" ? "selected" : ""; ?>>Menunggu Pembayaran</option><option value="Menunggu Verifikasi" <?= $data['status'] == "Menunggu Verifikasi" ? "selected" : ""; ?>>Menunggu Verifikasi</option><option value="Menunggu" <?= $data['status'] == "Menunggu" ? "selected" : ""; ?>>Menunggu / COD</option>
                    <option value="Diproses" <?= $data['status'] == "Diproses" ? "selected" : ""; ?>>Diproses</option>
                    <option value="Dikirim" <?= $data['status'] == "Dikirim" ? "selected" : ""; ?>>Dikirim</option><option value="Diterima" <?= $data['status'] == "Diterima" ? "selected" : ""; ?>>Diterima</option>
                    <option value="Pengajuan Pengembalian" <?= $data['status'] == "Pengajuan Pengembalian" ? "selected" : ""; ?>>Pengajuan Pengembalian</option>
                    <option value="Pengembalian Disetujui" <?= $data['status'] == "Pengembalian Disetujui" ? "selected" : ""; ?>>Pengembalian Disetujui</option>
                    <option value="Menunggu Barang Dikembalikan" <?= $data['status'] == "Menunggu Barang Dikembalikan" ? "selected" : ""; ?>>Menunggu Barang Dikembalikan</option>
                    <option value="Dana Dikembalikan" <?= $data['status'] == "Dana Dikembalikan" ? "selected" : ""; ?>>Dana Dikembalikan</option>
                    <option value="Selesai" <?= $data['status'] == "Selesai" ? "selected" : ""; ?>>Selesai</option><option value="Dibatalkan" <?= $data['status'] == "Dibatalkan" ? "selected" : ""; ?>>Dibatalkan</option>
                </select>
            </div>

            <button name="update" class="btn btn-success">
                Simpan
            </button>

            <a href="pesanan.php" class="btn btn-secondary">
                Kembali
            </a>
        </form>
    </div>

</body>

</html>