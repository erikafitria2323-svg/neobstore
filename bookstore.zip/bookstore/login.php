<?php
/**
 * Memproses login pengguna dengan memeriksa kredensial, memulai sesi, dan mengarahkan pengguna sesuai perannya.
 */
session_start();
include "config/koneksi.php";

$redirect = $_GET['redirect'] ?? '';

// Jika sudah login, arahkan sesuai rolenya masing-masing
if (isset($_SESSION['id_user'])) {
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } else {
        $target = ($redirect === 'cart') ? 'user/cart.php' : (($redirect === 'pesanan') ? 'user/pesanan.php' : 'index.php');
        header("Location: " . $target);
    }
    exit;
}

$error_msg = "";

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Ambil data user berdasarkan username atau email
    $stmt = mysqli_prepare($conn, "SELECT * FROM user WHERE username = ? OR email = ?");
    mysqli_stmt_bind_param($stmt, "ss", $username, $username);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result && mysqli_num_rows($result) === 1) {
        $user = mysqli_fetch_assoc($result);

        // Verifikasi password (mendukung hash maupun teks biasa)
        if (password_verify($password, $user['password']) || $password === $user['password']) {
            $_SESSION['id_user'] = $user['id_user'];
            $_SESSION['nama']    = $user['nama'];
            $_SESSION['role']    = $user['role']; // Menangkap role dengan benar ('admin' atau 'user')

            // PENGARAHAN BERDASARKAN ROLE
            if ($user['role'] === 'admin') {
                header("Location: admin/dashboard.php");
            } else {
                $target = ($redirect === 'cart') ? 'user/cart.php' : (($redirect === 'pesanan') ? 'user/pesanan.php' : 'index.php');
                header("Location: " . $target);
            }
            exit;
        } else {
            $error_msg = "Password yang Anda masukkan salah.";
        }
    } else {
        $error_msg = "Username atau email tidak ditemukan.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk - NEO BSTORE</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Google Fonts Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #FFFFFF;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .top-logo {
            position: absolute;
            top: 30px;
            left: 40px;
        }

        .logo-text {
            font-weight: 800;
            font-size: 22px;
            color: #000000;
            margin: 0;
        }

        .logo-text span {
            color: #3B82F6;
        }

        .auth-container {
            width: 100%;
            max-width: 380px;
            padding: 20px;
        }

        .auth-title {
            font-weight: 700;
            font-size: 20px;
            color: #0F172A;
            letter-spacing: 0.5px;
        }

        .custom-input-group {
            border: 1px solid #CBD5E1;
            border-radius: 12px;
            overflow: hidden;
            transition: all 0.2s ease;
            background-color: #FFFFFF;
        }

        .custom-input-group:focus-within {
            border-color: #3B82F6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15);
        }

        .custom-input-group .input-group-text {
            border: none;
            background: transparent;
            color: #64748B;
        }

        .custom-input-group .form-control {
            border: none;
            box-shadow: none;
            font-size: 13px;
            padding: 10px 12px 10px 0;
            font-weight: 500;
        }

        .btn-auth {
            background-color: #3B82F6;
            color: #FFFFFF;
            font-weight: 700;
            font-size: 14px;
            border-radius: 10px;
            padding: 10px;
            border: none;
            letter-spacing: 0.5px;
            transition: all 0.2s ease;
        }

        .btn-auth:hover {
            background-color: #2563EB;
            color: #FFFFFF;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
        }

        @media (max-width: 576px) {
            .top-logo {
                position: static;
                text-align: center;
                margin-bottom: 20px;
            }
            body {
                flex-direction: column;
                justify-content: flex-start;
                padding-top: 40px;
            }
        }
    </style>
</head>

<body>

    <div class="top-log"></div>
    <div class="top-logo">
        <h3 class="logo-text">NEO <span>BSTORE</span></h3>
    </div>

    <div class="auth-container">
        
        <h4 class="auth-title text-center mb-4">MASUK</h4>

        <?php if (!empty($error_msg)): ?>
            <div class="alert alert-danger alert-dismissible fade show small p-2 mb-3" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-1"></i> <?= htmlspecialchars($error_msg); ?>
                <button type="button" class="btn-close p-2" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <form method="POST" action="">
            
            <div class="input-group custom-input-group mb-3">
                <span class="input-group-text ps-3">
                    <i class="bi bi-person"></i>
                </span>
                <input type="text" name="username" class="form-control" placeholder="USERNAME / EMAIL" required autocomplete="off" value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>">
            </div>

            <div class="input-group custom-input-group mb-2">
                <span class="input-group-text ps-3">
                    <i class="bi bi-lock"></i>
                </span>
                <input type="password" id="password" name="password" class="form-control" placeholder="PASSWORD" required>
                <span class="input-group-text pe-3" style="cursor: pointer;" onclick="togglePassword()">
                    <i class="bi bi-eye" id="toggleIcon"></i>
                </span>
            </div>

            <div class="text-end mb-4">
                <a href="#" class="forgot-link text-primary text-decoration-none" style="font-size: 12px;">Lupa Password?</a>
            </div>

            <button type="submit" name="login" class="btn btn-auth w-100 mb-3">MASUK</button>

            <div class="text-center small text-secondary mt-3">
                Belum punya akun? <a href="register.php" class="text-primary text-decoration-none fw-semibold">Daftar di sini</a>
            </div>

        </form>

    </div>

    <script>
        // Mengubah visibilitas kolom kata sandi antara teks terlihat dan tersembunyi.
        function togglePassword() {
            const passInput = document.getElementById('password');
            const toggleIcon = document.getElementById('toggleIcon');
            
            if (passInput.type === 'password') {
                passInput.type = 'text';
                toggleIcon.classList.replace('bi-eye', 'bi-eye-slash');
            } else {
                passInput.type = 'password';
                toggleIcon.classList.replace('bi-eye-slash', 'bi-eye');
            }
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>